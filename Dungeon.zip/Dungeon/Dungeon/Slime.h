#pragma once

#include "AI.h"

class Slime : public AI {
public:
    Slime(int _x, int _y);
private:
};

Slime::Slime(int _x, int _y)
: AI(_x, _y, 50, 1, 1, 'S')
{
}